import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        /*
        Описание:

            Данное приложение является развлекательным и именуется как "Испорченный mail".
            Суть программы заключается в том, чтобы зафиксировать поздравления от пользователя нескольким получателям,
                после чего перемешать между собой фрагментами, и вывести пользователю.

         */
        int locationY = 20;                 //Базовое расположение окна ChatFrame
        int sizeFrame = 800;                //Ширина окна

        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        int locationX = (size.width - sizeFrame) / 2;


        // Создаём форму для нашей программы
        //JFrame f = new JFrame("Программа для генерации юмористических поздравлений \"Испорченный MAIL\"");
        JFrame f = new JFrame("Программа \"Испорченный MAIL\"");
        f.setBounds(locationX, locationY, sizeFrame, 700);                  //Пока размеры основного указаны без учёта размера экрана.

        f.setLocation(locationX, locationY);

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        f.setLayout(new BorderLayout());

        MenuListener listener = new MenuListener(f);



        JMenuBar mb = new JMenuBar();                                                      //Создание панели Меню
        JMenu main = new JMenu("Меню");                                                 //Создание пункта меню
        JMenuItem miHelp = new JMenuItem("Справка");                                  //Создание подпункта Справка
        JMenuItem miAboutProgram = new JMenuItem("О программе");                      //Создание подпункта О программе
        JMenuItem miExit = new JMenuItem("Выход");                                    //Создание подпункта Выход
        main.add(miHelp);
        main.add(miAboutProgram);
        main.addSeparator();                                                               //Добавление линии(разделителя)
        main.add(miExit);
        mb.add(main);

        //Фронтальная панель    ------------------------------------------------
        //JPanel front = new JPanel(new BorderLayout());
        int textSMS_rows = 6;
        int textSMS_columns = 65;

        JPanel front = new JPanel(new GridBagLayout());

        JTextArea mainDisplay = new JTextArea("Дисплей", 8, textSMS_columns);                                        //Основной дисплей приложения
//        int sizeDisplay = sizeFrame - 6;
//        mainDisplay.setSize(100, sizeDisplay);
        mainDisplay.setLineWrap(true);


        JTextArea textSMS1 = new JTextArea("Начало сообщения", textSMS_rows, textSMS_columns);                      //Поле сообщения 1
        textSMS1.setLineWrap(true);
        JTextArea textSMS2 = new JTextArea("Середина сообщения", textSMS_rows, textSMS_columns);                    //Поле сообщения 2
        textSMS2.setLineWrap(true);
        JTextArea textSMS3 = new JTextArea("Последнее сообщение", textSMS_rows, textSMS_columns);                   //Поле сообщения 3
        textSMS3.setLineWrap(true);

        JButton bLeft = new JButton("<<<");                                                                         //Стрелка влево
        JTextField tfIDSMS = new JTextField("0");
        JButton bRight = new JButton(">>>");                                                                        //Стрелка вправо


        front.add(new JScrollPane(mainDisplay));

//        front.add(bLeft);
//        front.add(tfIDSMS);
//        front.add(bRight);
//
//        front.add(textSMS1);
//        front.add(textSMS2);
//        front.add(textSMS3);


        GridBagConstraints c = new GridBagConstraints();            //Настроить
        c.gridwidth = 3;
        c.insets = new Insets(0, 0, 10, 0);

        //Добавление дисплея
        c.gridx = 1;
        c.gridy = 0;
        front.add(mainDisplay, c);

        //Добавление кнопок с индексом
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = 1;
        front.add(bLeft, c);
        c.gridx = 1;
        front.add(tfIDSMS, c);
        c.gridx = 2;
        front.add(bRight, c);

        //Первое поле СМС
        c.gridwidth = 3;
        c.gridy = 2;
        front.add(textSMS1, c);

        //Второе поле СМС
        c.gridy = 3;
        front.add(textSMS2, c);

        //Третье поле СМС
        c.gridy = 4;
        front.add(textSMS3, c);


        //Подвал    ------------------------------------------------------------
        JPanel bottom = new JPanel();

        JButton bStart = new JButton("Старт");
        JButton bClear = new JButton("Очистить");
        JButton bSave = new JButton("Запомнить");
        JButton bSet = new JButton("Редактировать");

        bottom.add(bStart);
        bottom.add(bClear);
        bottom.add(bSave);
        bottom.add(bSet);



        f.setJMenuBar(mb);

        miExit.addActionListener(listener);

        f.add(front, BorderLayout.CENTER);
        f.add(bottom, BorderLayout.SOUTH);

        f.setVisible(true);
    }

}
