import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuListener implements ActionListener {

    JFrame frame;

    public MenuListener(JFrame frame) {
        this.frame = frame;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println(e.getActionCommand());
        String c = e.getActionCommand();
        switch (c) {
            case "Выход":
                System.exit(0);
            case "Справка":


                break;
            case "О программе":

                break;
        }
    }
}
