public class TextErrMSG {

}
